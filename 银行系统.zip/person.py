class Person(object):
    def __init__(self, id, tel, card, name):
        self.userId = id
        self.userTelNum = tel
        self.card = card
        self.name = name

