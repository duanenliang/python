class Card(object):
    def __init__(self, cardId, passwd, money):
        self.cardId = cardId
        self.cardPasswd = passwd
        self.cardMoney = money
